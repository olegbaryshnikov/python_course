import setuptools


setuptools.setup(
    name="latex_gen",
    version="0.0.1",
    description="Latex file generator",
    packages=setuptools.find_packages(),
    install_requires=[],
    package_data={},
    python_requires=">=3.11",
)
